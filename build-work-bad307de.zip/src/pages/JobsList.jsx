import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Briefcase, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import JobCard from "../components/jobs/JobCard";
import { useLanguage } from "../components/LanguageContext";
import CategorySelector from "../components/CategorySelector";

const regions = [
  "Toshkent Shahar", "Toshkent Viloyati", "Samarqand", "Farg'ona",
  "Andijon", "Namangan", "Buxoro", "Navoiy", "Qashqadaryo",
  "Surxondaryo", "Jizzax", "Sirdaryo", "Xorazm", "Qoraqalpog'iston"
];

const regionsData = {
  "Toshkent Shahar": ["Chilonzor", "Yunusobod", "Sergeli", "Yakkasaroy", "Olmazor", "Shayxontohur", "Mirzo Ulugbek", "Uchtepa", "Bektemir", "Mirobod"],
  "Toshkent Viloyati": ["Chirchiq", "Olmaliq", "Angren", "Bekobod", "Nurafshon", "Yangiyo'l", "Bo'ka", "Oqqo'rg'on", "Parkent"],
  "Samarqand": ["Samarqand shahri", "Urgut", "Kattaqo'rg'on", "Ishtixon", "Nurobod"],
  "Farg'ona": ["Farg'ona shahri", "Qo'qon", "Marg'ilon", "Quva", "Rishton"],
  "Andijon": ["Andijon shahri", "Asaka", "Xo'jaobod", "Shahrixon"],
  "Namangan": ["Namangan shahri", "Chortoq", "Chust", "Pop"],
  "Buxoro": ["Buxoro shahri", "G'ijduvon", "Kogon", "Romitan"],
  "Navoiy": ["Navoiy shahri", "Zarafshon", "Uchquduq"],
  "Qashqadaryo": ["Qarshi", "Shahrisabz", "Dehqonobod"],
  "Surxondaryo": ["Termiz", "Denov", "Sherobod", "Boysun"],
  "Jizzax": ["Jizzax shahri", "Zomin", "G'allaorol"],
  "Sirdaryo": ["Guliston", "Sirdaryo shahri", "Yangiyer"],
  "Xorazm": ["Urganch", "Xiva", "Bog'ot"],
  "Qoraqalpog'iston": ["Nukus", "Taxiatosh", "Xo'jayli", "Chimboy"]
};

export default function JobsList() {
  const { t } = useLanguage();
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [jobTypeFilter, setJobTypeFilter] = useState("all");
  const [regionFilter, setRegionFilter] = useState("all");
  const [cityFilter, setCityFilter] = useState("all");

  const cities = regionFilter !== "all" ? regionsData[regionFilter] || [] : [];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ['jobs'],
    queryFn: () => base44.entities.Job.filter({ status: "open" }, "-created_date"),
    initialData: []
  });

  const filteredJobs = jobs.filter((job) => {
    const jobCategories = job.categories || (job.category ? [job.category] : []);
    const matchesCategory = selectedCategories.length === 0 || 
      jobCategories.some(cat => selectedCategories.includes(cat));
    const matchesJobType = jobTypeFilter === "all" || job.job_type === jobTypeFilter;
    const matchesRegion = regionFilter === "all" || job.region === regionFilter;
    const matchesCity = cityFilter === "all" || job.city === cityFilter;
    return matchesCategory && matchesJobType && matchesRegion && matchesCity;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {t('availablePositions')}
              </h1>
              <p className="text-gray-600">{filteredJobs.length} {t('jobsFound')}</p>
            </div>
            <Link to={createPageUrl("PostJob")}>
              <Button className="bg-orange-500 hover:bg-orange-600">
                {t('postAJob')}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Filters */}
        <div className="mb-8 space-y-4">
          <CategorySelector 
            selectedCategories={selectedCategories}
            onChange={setSelectedCategories}
          />
          
          <div className="flex flex-col sm:flex-row gap-3">
            <Select value={regionFilter} onValueChange={(value) => {
              setRegionFilter(value);
              setCityFilter("all");
            }}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder={t('region')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allRegions')}</SelectItem>
                {regions.map((region) => (
                  <SelectItem key={region} value={region}>{region}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={cityFilter} onValueChange={setCityFilter} disabled={regionFilter === "all"}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder={regionFilter === "all" ? t('selectRegionFirst') : t('cityDistrict')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allCities')}</SelectItem>
                {cities.map((city) => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={jobTypeFilter} onValueChange={setJobTypeFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder={t('jobType')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allTypes')}</SelectItem>
                <SelectItem value="full_time">{t('fullTime')}</SelectItem>
                <SelectItem value="part_time">{t('partTime')}</SelectItem>
                <SelectItem value="contract">{t('contract')}</SelectItem>
                <SelectItem value="temporary">{t('temporary')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Jobs Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-4" />
                <div className="h-3 bg-gray-200 rounded w-1/2 mb-6" />
                <div className="h-3 bg-gray-200 rounded w-full mb-2" />
                <div className="h-3 bg-gray-200 rounded w-2/3" />
              </Card>
            ))}
          </div>
        ) : filteredJobs.length === 0 ? (
          <Card className="p-12 text-center">
            <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">{t('noJobsFound')}</h3>
            <p className="text-gray-600 mb-6">{t('noJobsDesc')}</p>
            <Button onClick={() => {
              setSelectedCategories([]);
              setJobTypeFilter("all");
              setRegionFilter("all");
              setCityFilter("all");
            }}>
              {t('clearFilters')}
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredJobs.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}