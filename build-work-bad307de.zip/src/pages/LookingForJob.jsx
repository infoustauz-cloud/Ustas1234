import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, X, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { useLanguage } from "../components/LanguageContext";
import CategorySelector from "../components/CategorySelector";
import RegionCitySelector from "../components/RegionCitySelector";

export default function LookingForJob() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { t } = useLanguage();
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    location: "",
    region: "",
    city: "",
    job_title: "",
    categories: [],
    experience_level: "intermediate",
    years_experience: "",
    skills: [],
    instagram: "",
    facebook: "",
    telegram: "",
    profile_image: "",
    bio: ""
  });
  const [newSkill, setNewSkill] = useState("");
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setFormData(prev => ({
        ...prev,
        full_name: u.full_name || "",
        email: u.email || "",
        phone: u.phone || "",
        location: u.location || "",
        job_title: u.job_title || "",
        years_experience: u.years_experience || "",
        skills: u.skills || [],
        instagram: u.instagram || "",
        facebook: u.facebook || "",
        telegram: u.telegram || "",
        profile_image: u.profile_image || "",
        bio: u.bio || ""
      }));
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const createJobSeekerMutation = useMutation({
    mutationFn: (data) => base44.entities.JobSeeker.create({
      ...data,
      years_experience: data.years_experience ? parseFloat(data.years_experience) : null,
      status: "active"
    }),
    onSuccess: () => {
      toast.success("Profile registered successfully!");
      navigate(createPageUrl("Home"));
    },
    onError: () => {
      toast.error("Failed to register profile");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createJobSeekerMutation.mutate(formData);
  };

  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData({...formData, skills: [...formData.skills, newSkill.trim()]});
      setNewSkill("");
    }
  };

  const removeSkill = (skill) => {
    setFormData({...formData, skills: formData.skills.filter(s => s !== skill)});
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, profile_image: file_url }));
      toast.success("Photo uploaded successfully!");
    } catch (error) {
      toast.error("Failed to upload photo");
    }
    setUploadingImage(false);
  };

  const getCategoryLabel = (cat) => {
    const key = cat.replace(/_/g, '').replace(/\s+/g, '').toLowerCase();
    const formatted = key.charAt(0).toUpperCase() + key.slice(1);
    return t(key) !== key ? t(key) : cat.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('lookingForJob')}</h1>
          <p className="text-gray-600">{t('fillJobSeekerDetails')}</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            {/* Basic Information */}
            <Card className="p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">{t('basicInfo')}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <Label htmlFor="full_name">{t('fullName')} *</Label>
                  <Input
                    id="full_name"
                    required
                    value={formData.full_name}
                    onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="email">{t('email')} *</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="phone">{t('phone')}</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder={t('phonePlaceholder')}
                    className="mt-1"
                  />
                </div>

                <div className="md:col-span-2">
                  <RegionCitySelector
                    selectedRegion={formData.region}
                    selectedCity={formData.city}
                    onRegionChange={(region) => setFormData({...formData, region, location: `${region}`})}
                    onCityChange={(city) => setFormData({...formData, city, location: `${city}, ${formData.region}`})}
                    regionLabel={t('region')}
                    cityLabel={t('cityDistrict')}
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="bio">{t('bio')}</Label>
                  <Textarea
                    id="bio"
                    rows={4}
                    value={formData.bio}
                    onChange={(e) => setFormData({...formData, bio: e.target.value})}
                    placeholder={t('bioPlaceholder')}
                    className="mt-1"
                  />
                </div>
              </div>
            </Card>

            {/* Job Preferences */}
            <Card className="p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">{t('jobPreferences')}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <Label htmlFor="job_title">{t('desiredJobTitle')} *</Label>
                  <Input
                    id="job_title"
                    required
                    value={formData.job_title}
                    onChange={(e) => setFormData({...formData, job_title: e.target.value})}
                    placeholder={t('desiredJobTitlePlaceholder')}
                    className="mt-1"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label>{t('category')} *</Label>
                  <p className="text-sm text-gray-600 mb-3">{t('selectMultipleCategories')}</p>
                  <CategorySelector 
                    selectedCategories={formData.categories}
                    onChange={(categories) => setFormData({...formData, categories})}
                  />
                </div>

                <div>
                  <Label htmlFor="experience_level">{t('experienceLevel')}</Label>
                  <Select value={formData.experience_level} onValueChange={(value) => setFormData({...formData, experience_level: value})}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="entry">{t('entryLevel')}</SelectItem>
                      <SelectItem value="intermediate">{t('intermediate')}</SelectItem>
                      <SelectItem value="senior">{t('senior')}</SelectItem>
                      <SelectItem value="expert">{t('expert')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="years_experience">{t('yearsExperience')}</Label>
                  <Input
                    id="years_experience"
                    type="number"
                    min="0"
                    value={formData.years_experience}
                    onChange={(e) => setFormData({...formData, years_experience: e.target.value})}
                    className="mt-1"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="profile_image">{t('profilePicture')} ({t('optional')})</Label>
                  <div className="mt-2 space-y-3">
                    {formData.profile_image && (
                      <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-orange-500">
                        <img 
                          src={formData.profile_image} 
                          alt="Profile" 
                          className="w-full h-full object-cover" 
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-1 right-1 h-6 w-6 rounded-full"
                          onClick={() => setFormData(prev => ({ ...prev, profile_image: "" }))}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                    <input
                      id="profile_image"
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('profile_image').click()}
                      disabled={uploadingImage}
                      className="w-full"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {uploadingImage ? t('uploading') : (formData.profile_image ? t('changePhoto') : t('uploadPhoto'))}
                    </Button>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <Label>{t('skills')}</Label>
                  <div className="mt-2 space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {formData.skills.map((skill, idx) => (
                        <Badge key={idx} className="bg-orange-100 text-orange-700 border-orange-200">
                          {skill}
                          <button
                            type="button"
                            onClick={() => removeSkill(skill)}
                            className="ml-2 hover:text-orange-900"
                          >
                            ×
                          </button>
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Input
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        placeholder={t('skillPlaceholder')}
                        onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                      />
                      <Button type="button" onClick={addSkill}>{t('add')}</Button>
                    </div>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <Label>{t('socialMedia')} ({t('optional')})</Label>
                  <div className="space-y-3 mt-2">
                    <div>
                      <Label htmlFor="instagram" className="text-sm text-gray-600">Instagram</Label>
                      <Input
                        id="instagram"
                        value={formData.instagram}
                        onChange={(e) => setFormData({...formData, instagram: e.target.value})}
                        placeholder="https://instagram.com/yourusername"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="facebook" className="text-sm text-gray-600">Facebook</Label>
                      <Input
                        id="facebook"
                        value={formData.facebook}
                        onChange={(e) => setFormData({...formData, facebook: e.target.value})}
                        placeholder="https://facebook.com/yourprofile"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="telegram" className="text-sm text-gray-600">Telegram</Label>
                      <Input
                        id="telegram"
                        value={formData.telegram}
                        onChange={(e) => setFormData({...formData, telegram: e.target.value})}
                        placeholder="@yourusername"
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Submit */}
            <div className="flex gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(createPageUrl("Home"))}
                className="flex-1"
              >
                {t('cancel')}
              </Button>
              <Button
                type="submit"
                disabled={createJobSeekerMutation.isPending}
                className="flex-1 bg-orange-500 hover:bg-orange-600"
              >
                {createJobSeekerMutation.isPending ? t('submitting') : t('registerProfile')}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}