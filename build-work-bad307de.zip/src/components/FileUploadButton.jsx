import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Upload, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function FileUploadButton({ onUploadSuccess, accept = "*", children, className }) {
    const [uploading, setUploading] = useState(false);

    const handleFileChange = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setUploading(true);
        try {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('bucket', 'public-files');

            const response = await base44.functions.invoke('supabaseUpload', formData);
            
            if (response.data.success) {
                toast.success('File uploaded successfully!');
                onUploadSuccess?.(response.data.public_url, response.data.file_path);
            } else {
                toast.error(response.data.error || 'Upload failed');
            }
        } catch (error) {
            toast.error('Failed to upload file');
            console.error('Upload error:', error);
        } finally {
            setUploading(false);
        }
    };

    return (
        <div>
            <input
                type="file"
                id="file-upload"
                accept={accept}
                onChange={handleFileChange}
                className="hidden"
                disabled={uploading}
            />
            <label htmlFor="file-upload">
                <Button
                    type="button"
                    variant="outline"
                    disabled={uploading}
                    className={className}
                    asChild
                >
                    <span>
                        {uploading ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                            <Upload className="w-4 h-4 mr-2" />
                        )}
                        {children || (uploading ? 'Uploading...' : 'Upload File')}
                    </span>
                </Button>
            </label>
        </div>
    );
}