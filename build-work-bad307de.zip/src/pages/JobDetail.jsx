import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, MapPin, Briefcase, DollarSign, Clock, Calendar, 
  Building2, CheckCircle, Send, User, Phone, Mail, Trash2, MessageSquare, ChevronLeft, ChevronRight, Edit
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { format } from "date-fns";
import { useLanguage } from "../components/LanguageContext";

export default function JobDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { t } = useLanguage();
  const urlParams = new URLSearchParams(window.location.search);
  const jobId = urlParams.get("id");
  const [user, setUser] = useState(null);
  const [showMessageForm, setShowMessageForm] = useState(false);
  const [messageText, setMessageText] = useState("");
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const [jobSeekerProfile, setJobSeekerProfile] = useState(null);
  const [hasApplied, setHasApplied] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [jobId]);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
    }).catch(() => setUser(null));
  }, []);

  const { data: userApplications = [] } = useQuery({
    queryKey: ['user-applications', user?.email, jobId],
    queryFn: () => base44.entities.Application.filter({ 
      job_id: jobId,
      created_by: user.email 
    }),
    enabled: !!user && !!jobId
  });

  const { data: jobSeekerProfiles = [] } = useQuery({
    queryKey: ['jobseeker-profile', user?.email],
    queryFn: () => base44.entities.JobSeeker.filter({ created_by: user.email }),
    enabled: !!user
  });

  useEffect(() => {
    if (jobSeekerProfiles.length > 0) {
      setJobSeekerProfile(jobSeekerProfiles[0]);
    }
  }, [jobSeekerProfiles]);

  useEffect(() => {
    setHasApplied(userApplications.length > 0);
  }, [userApplications]);

  const { data: job, isLoading } = useQuery({
    queryKey: ['job', jobId],
    queryFn: async () => {
      const jobs = await base44.entities.Job.filter({ id: jobId });
      return jobs[0];
    },
    enabled: !!jobId
  });

  const deleteJobMutation = useMutation({
    mutationFn: () => base44.entities.Job.delete(jobId),
    onSuccess: () => {
      toast.success("Job deleted successfully!");
      navigate(createPageUrl("Home"));
    },
    onError: () => {
      toast.error("Failed to delete job");
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: (data) => base44.entities.Message.create(data),
    onSuccess: () => {
      toast.success(t('messages') + " sent!");
      setShowMessageForm(false);
      setMessageText("");
      navigate(createPageUrl("Messages"));
    },
    onError: () => {
      toast.error("Failed to send message");
    }
  });

  const applyMutation = useMutation({
    mutationFn: async () => {
      if (!user) {
        base44.auth.redirectToLogin(window.location.href);
        throw new Error("Please log in to apply");
      }
      if (!jobSeekerProfile) {
        throw new Error("Please create a profile first");
      }
      return base44.entities.Application.create({
        job_id: jobId,
        applicant_name: user.full_name,
        applicant_email: user.email,
        applicant_phone: jobSeekerProfile.phone || "",
        years_experience: jobSeekerProfile.years_experience || 0,
        certifications: [],
        cover_letter: `I'm interested in the ${job.title} position and would like to discuss this opportunity with you.`
      });
    },
    onSuccess: () => {
      toast.success("You have applied for this position!");
      queryClient.invalidateQueries({ queryKey: ['user-applications'] });
      setShowMessageForm(true);
    },
    onError: (error) => {
      if (error.message === "Please create a profile first") {
        toast.error("Please create your profile first to apply for jobs");
        setTimeout(() => {
          navigate(createPageUrl("Profile"));
        }, 2000);
      } else {
        toast.error(error.message || "Failed to submit application");
      }
    }
  });

  const handleApplyNow = () => {
    if (!user) {
      base44.auth.redirectToLogin(window.location.href);
      return;
    }
    if (!jobSeekerProfile) {
      toast.error("Please create your profile first to apply for jobs");
      setTimeout(() => {
        navigate(createPageUrl("Profile"));
      }, 2000);
      return;
    }
    applyMutation.mutate();
  };

  const handleDelete = () => {
    if (window.confirm("Are you sure you want to delete this job?")) {
      deleteJobMutation.mutate();
    }
  };

  const handleSendMessage = () => {
    if (!user) {
      base44.auth.redirectToLogin(window.location.href);
      return;
    }
    
    if (!messageText.trim()) return;
    
    sendMessageMutation.mutate({
      job_id: jobId,
      sender_email: user.email,
      sender_name: user.full_name,
      receiver_email: job.created_by,
      message: messageText.trim()
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4" />
          <div className="h-64 bg-gray-200 rounded" />
          <div className="h-32 bg-gray-200 rounded" />
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('jobNotFound')}</h2>
        <Button onClick={() => navigate(createPageUrl("Home"))}>
          {t('backToJobs')}
        </Button>
      </div>
    );
  }

  const formatSalary = () => {
    if (!job.salary_min) return t('salaryNegotiable');
    const min = job.salary_min.toLocaleString();
    const max = job.salary_max ? job.salary_max.toLocaleString() : null;
    const period = job.salary_period || "hourly";
    if (max) return `$${min} - $${max} / ${t(period)}`;
    return `$${min} / ${t(period)}`;
  };

  const isJobOwner = user && user.email === job.created_by;
  const images = job.image_urls || [];

  // Debug logging
  console.log('User:', user?.email);
  console.log('Job created_by:', job?.created_by);
  console.log('Is Job Owner:', isJobOwner);

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section - Image Carousel */}
      {images.length > 0 && (
        <div className="h-96 bg-gray-900 relative">
          <img 
            src={images[currentImageIndex]} 
            alt={`${job.title} - Image ${currentImageIndex + 1}`}
            className="w-full h-full object-contain"
          />
          
          {images.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white h-12 w-12"
                onClick={prevImage}
              >
                <ChevronLeft className="w-6 h-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white h-12 w-12"
                onClick={nextImage}
              >
                <ChevronRight className="w-6 h-6" />
              </Button>
              
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {images.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentImageIndex(idx)}
                    className={`h-2 rounded-full transition-all ${
                      idx === currentImageIndex 
                        ? 'w-8 bg-white' 
                        : 'w-2 bg-white/50 hover:bg-white/75'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate(createPageUrl("JobsList"))}
            className="hover:bg-gray-100"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t('backToJobs')}
          </Button>

          {isJobOwner && (
            <div className="flex gap-2">
              <Button 
                variant="outline"
                onClick={() => navigate(createPageUrl(`EditJob?id=${jobId}`))}
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
              <Button 
                variant="destructive"
                onClick={handleDelete}
                disabled={deleteJobMutation.isPending}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                {deleteJobMutation.isPending ? t('deleting') : 'Delete'}
              </Button>
            </div>
          )}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="p-8">
              <div className="mb-6">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{job.title}</h1>
                <div className="flex items-center gap-2 text-gray-600 mb-4">
                  <Building2 className="w-5 h-5" />
                  <span className="text-lg">{job.company}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(job.categories || (job.category ? [job.category] : [])).filter(cat => cat).map((cat, idx) => (
                    <Badge key={idx} className="bg-orange-100 text-orange-700 border-orange-200">
                      {t(cat) || cat.replace(/_/g, ' ')}
                    </Badge>
                  ))}
                  <Badge variant="outline">
                    {t(job.job_type) || job.job_type?.replace(/_/g, ' ') || 'N/A'}
                  </Badge>
                  {job.experience_level && (
                    <Badge variant="outline">
                      {t(job.experience_level)} {t('level')}
                    </Badge>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 p-4 bg-gray-50 rounded-lg">
                {job.region && (
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-orange-500" />
                    <div>
                      <p className="text-xs text-gray-500">{t('region')}</p>
                      <p className="font-medium">{job.region}</p>
                    </div>
                  </div>
                )}
                {job.city && (
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-orange-500" />
                    <div>
                      <p className="text-xs text-gray-500">{t('cityDistrict')}</p>
                      <p className="font-medium">{job.city}</p>
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-3">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-xs text-gray-500">{t('compensation')}</p>
                    <p className="font-medium">{formatSalary()}</p>
                  </div>
                </div>
                {job.start_date && (
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-blue-500" />
                    <div>
                      <p className="text-xs text-gray-500">{t('startDate')}</p>
                      <p className="font-medium">{format(new Date(job.start_date), "MMM d, yyyy")}</p>
                    </div>
                  </div>
                )}
                {job.duration && (
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-purple-500" />
                    <div>
                      <p className="text-xs text-gray-500">{t('duration')}</p>
                      <p className="font-medium">{job.duration}</p>
                    </div>
                  </div>
                )}
              </div>

              {job.description && (
                <div className="mb-8">
                  <h2 className="text-xl font-bold text-gray-900 mb-4">{t('jobDescription')}</h2>
                  <p className="text-gray-700 whitespace-pre-line leading-relaxed">{job.description}</p>
                </div>
              )}

              {job.requirements && job.requirements.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-xl font-bold text-gray-900 mb-4">{t('requirements')}</h2>
                  <ul className="space-y-2">
                    {job.requirements.map((req, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {job.benefits && job.benefits.length > 0 && (
                <div>
                  <h2 className="text-xl font-bold text-gray-900 mb-4">{t('benefits')}</h2>
                  <ul className="space-y-2">
                    {job.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </Card>

            {/* Message Form */}
            {showMessageForm && !isJobOwner && (
              <Card className="p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('contactEmployer')}</h2>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="message">{t('messages')}</Label>
                    <Textarea
                      id="message"
                      rows={6}
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder="Write your message to the employer..."
                      className="mt-1"
                    />
                  </div>
                  <div className="flex gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowMessageForm(false)}
                      className="flex-1"
                    >
                      {t('cancel')}
                    </Button>
                    <Button
                      onClick={handleSendMessage}
                      disabled={!messageText.trim() || sendMessageMutation.isPending}
                      className="flex-1 bg-orange-500 hover:bg-orange-600"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {sendMessageMutation.isPending ? t('submitting') : t('messages')}
                    </Button>
                  </div>
                </div>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="p-6 sticky top-24">
              {!isJobOwner ? (
                <>
                  {hasApplied ? (
                    <>
                      <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center gap-2 text-green-800">
                          <CheckCircle className="w-5 h-5" />
                          <p className="font-semibold">You have applied for this position</p>
                        </div>
                      </div>
                      <Button 
                        variant="outline"
                        className="w-full mb-3 h-12 text-base font-semibold"
                        onClick={() => setShowMessageForm(!showMessageForm)}
                      >
                        <MessageSquare className="w-4 h-4 mr-2" />
                        {t('messages')}
                      </Button>
                      {(job.contact_email || job.contact_phone) && (
                        <Button 
                          className="w-full mb-4 h-12 text-base font-semibold bg-green-600 hover:bg-green-700"
                          onClick={() => {
                            if (job.contact_email && job.contact_phone) {
                              const choice = window.confirm(
                                `${t('contactEmployer')}\n\nEmail: ${job.contact_email}\nPhone: ${job.contact_phone}\n\nClick OK for Email, Cancel for Phone`
                              );
                              if (choice) {
                                window.location.href = `mailto:${job.contact_email}`;
                              } else {
                                window.location.href = `tel:${job.contact_phone}`;
                              }
                            } else if (job.contact_email) {
                              window.location.href = `mailto:${job.contact_email}`;
                            } else if (job.contact_phone) {
                              window.location.href = `tel:${job.contact_phone}`;
                            }
                          }}
                        >
                          <Phone className="w-4 h-4 mr-2" />
                          {t('contactEmployer')}
                        </Button>
                      )}
                    </>
                  ) : (
                    <Button 
                      className="w-full bg-orange-500 hover:bg-orange-600 mb-3 h-12 text-base font-semibold"
                      onClick={handleApplyNow}
                      disabled={applyMutation.isPending}
                    >
                      {applyMutation.isPending ? t('submitting') : t('applyNow')}
                    </Button>
                  )}
                </>
              ) : (
                <div className="space-y-3">
                  <Button 
                    className="w-full h-12 text-base font-semibold bg-blue-500 hover:bg-blue-600"
                    onClick={() => navigate(createPageUrl(`EditJob?id=${jobId}`))}
                  >
                    Edit Job
                  </Button>
                  <Button 
                    variant="destructive"
                    className="w-full h-12 text-base font-semibold"
                    onClick={handleDelete}
                    disabled={deleteJobMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    {deleteJobMutation.isPending ? t('deleting') : t('deleteJob')}
                  </Button>
                </div>
              )}

              {(isJobOwner || hasApplied) && (
                <div className="space-y-4 pt-4 border-t">
                  <h3 className="font-semibold text-gray-900">{t('contactInfo')}</h3>
                  {job.contact_name && (
                    <div className="flex items-start gap-3 text-sm">
                      <User className="w-4 h-4 text-gray-400 mt-0.5" />
                      <span className="text-gray-700">{job.contact_name}</span>
                    </div>
                  )}
                  {job.contact_email && (
                    <div className="flex items-start gap-3 text-sm">
                      <Mail className="w-4 h-4 text-gray-400 mt-0.5" />
                      <a href={`mailto:${job.contact_email}`} className="text-orange-600 hover:underline">
                        {job.contact_email}
                      </a>
                    </div>
                  )}
                  {job.contact_phone && (
                    <div className="flex items-start gap-3 text-sm">
                      <Phone className="w-4 h-4 text-gray-400 mt-0.5" />
                      <a href={`tel:${job.contact_phone}`} className="text-orange-600 hover:underline">
                        {job.contact_phone}
                      </a>
                    </div>
                  )}
                </div>
              )}

              <div className="pt-4 border-t mt-4">
                <p className="text-xs text-gray-500">
                  {t('posted')} {format(new Date(job.created_date), "MMM d, yyyy")}
                </p>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}