import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLanguage } from "./LanguageContext";

const regions = [
  { label: "Tashkent Shahar", value: "tashkent_shahar" },
  { label: "Tashkent Viloyati", value: "tashkent_viloyati" },
  { label: "Samarkand", value: "samarkand" },
  { label: "Farg'ona", value: "fargona" },
  { label: "Andijon", value: "andijon" },
  { label: "Namangan", value: "namangan" },
  { label: "Buxoro", value: "buxoro" },
  { label: "Navoiy", value: "navoiy" },
  { label: "Qashqadaryo", value: "qashqadaryo" },
  { label: "Surxondaryo", value: "surxondaryo" },
  { label: "Jizzax", value: "jizzax" }
];

const citiesByRegion = {
  tashkent_shahar: [
    { label: "Shayxontohur", value: "shayxontohur" },
    { label: "Chilonzor", value: "chilonzor" },
    { label: "Yunusobod", value: "yunusobod" },
    { label: "Mirzo Ulug'bek", value: "mirzo_ulugbek" },
    { label: "Sergeli", value: "sergeli" },
    { label: "Yakkasaroy", value: "yakkasaroy" }
  ],
  tashkent_viloyati: [
    { label: "Angren", value: "angren" },
    { label: "Oqqo'rg'on", value: "oqqorgon" },
    { label: "Chirchiq", value: "chirchiq" },
    { label: "Olmaliq", value: "olmaliq" },
    { label: "Piskent", value: "piskent" },
    { label: "Bekobod", value: "bekobod" }
  ],
  samarkand: [
    { label: "Samarkand city", value: "samarkand_city" },
    { label: "Bulung'ur", value: "bulungur" },
    { label: "Payariq", value: "payariq" },
    { label: "Jomboy", value: "jomboy" },
    { label: "Siyob", value: "siyob" }
  ],
  namangan: [
    { label: "Namangan city", value: "namangan_city" },
    { label: "Uychi", value: "uychi" },
    { label: "Chortoq", value: "chortoq" },
    { label: "Chust", value: "chust" },
    { label: "Pop", value: "pop" }
  ],
  fargona: [],
  andijon: [],
  buxoro: [],
  navoiy: [],
  qashqadaryo: [],
  surxondaryo: [],
  jizzax: []
};

export default function RegionCitySelector({ 
  selectedRegion, 
  selectedCity,
  manualAddress = "",
  onRegionChange, 
  onCityChange,
  onManualAddressChange,
  regionLabel,
  cityLabel,
  addressLabel,
  addressPlaceholder,
  disabled = false
}) {
  const { t } = useLanguage();
  const cities = selectedRegion ? citiesByRegion[selectedRegion] || [] : [];
  
  const finalRegionLabel = regionLabel || t('region');
  const finalCityLabel = cityLabel || t('cityDistrict');
  const finalAddressLabel = addressLabel || t('address');
  const finalAddressPlaceholder = addressPlaceholder || t('addressPlaceholder');

  const handleRegionChange = (regionValue) => {
    onRegionChange(regionValue);
    onCityChange("");
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div>
        <Label htmlFor="manualAddress">{finalAddressLabel}</Label>
        <Input
          id="manualAddress"
          value={manualAddress}
          onChange={(e) => onManualAddressChange?.(e.target.value)}
          placeholder={finalAddressPlaceholder}
          disabled={disabled}
          className="mt-1"
        />
      </div>

      <div>
        <Label htmlFor="regionSelect">{finalRegionLabel}</Label>
        <Select value={selectedRegion} onValueChange={handleRegionChange} disabled={disabled}>
          <SelectTrigger id="regionSelect" className="mt-1">
            <SelectValue placeholder={t('selectRegion')} />
          </SelectTrigger>
          <SelectContent>
            {regions.map((region) => (
              <SelectItem key={region.value} value={region.value}>
                {region.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="citySelect">{finalCityLabel}</Label>
        <Select 
          value={selectedCity} 
          onValueChange={onCityChange} 
          disabled={disabled || !selectedRegion || cities.length === 0}
        >
          <SelectTrigger id="citySelect" className="mt-1 disabled:opacity-50 disabled:cursor-not-allowed">
            <SelectValue placeholder={selectedRegion ? t('selectCity') : t('selectRegionFirst')} />
          </SelectTrigger>
          <SelectContent>
            {cities.map((city) => (
              <SelectItem key={city.value} value={city.value}>
                {city.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}